package UI.view;

import javafx.scene.control.TextArea;

public class TerminalView extends TextArea {

    public TerminalView() {
        setEditable(false);
        setPrefHeight(100);
    }
}
