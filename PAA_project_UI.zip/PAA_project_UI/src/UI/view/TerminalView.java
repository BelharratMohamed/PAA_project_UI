package UI.view;

import javafx.scene.control.TextArea;

public class TerminalView extends TextArea {

    public TerminalView() {
        setEditable(false);
        setPrefWidth(400);
    }
}
